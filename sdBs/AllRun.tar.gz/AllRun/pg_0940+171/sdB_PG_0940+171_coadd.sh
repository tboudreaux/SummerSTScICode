#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_PG_0940+171/
python sdB_PG_0940+171_coadd.py
date