#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ910_172800.96+310318.1/
python sdB_SDSSJ910_172800.96+310318.1_coadd.py
date