#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_galex_j022454.87+010938.81/
python sdB_galex_j022454.87+010938.81_coadd.py
date