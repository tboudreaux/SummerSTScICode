#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ910_084328.87+082438.2/
python sdB_SDSSJ910_084328.87+082438.2_lc.py
date