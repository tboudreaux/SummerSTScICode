#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj9-10_084328.87+082438.2/
python sdB_sdssj9-10_084328.87+082438.2_lc.py
date