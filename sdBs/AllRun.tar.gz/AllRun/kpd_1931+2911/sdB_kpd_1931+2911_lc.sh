#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_kpd_1931+2911/
python sdB_kpd_1931+2911_lc.py
date