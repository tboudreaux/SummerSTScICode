#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_o11_j190344+472439/
python sdB_o11_j190344+472439_coadd.py
date