#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ_162051.03+375059.3/
python sdB_SDSSJ_162051.03+375059.3_coadd.py
date