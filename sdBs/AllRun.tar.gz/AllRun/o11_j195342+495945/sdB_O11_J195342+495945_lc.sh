#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_O11_J195342+495945/
python sdB_O11_J195342+495945_lc.py
date