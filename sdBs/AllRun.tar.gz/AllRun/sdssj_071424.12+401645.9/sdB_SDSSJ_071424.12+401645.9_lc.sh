#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ_071424.12+401645.9/
python sdB_SDSSJ_071424.12+401645.9_lc.py
date