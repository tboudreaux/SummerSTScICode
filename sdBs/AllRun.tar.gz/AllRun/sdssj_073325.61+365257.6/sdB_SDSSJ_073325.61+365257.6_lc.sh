#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ_073325.61+365257.6/
python sdB_SDSSJ_073325.61+365257.6_lc.py
date