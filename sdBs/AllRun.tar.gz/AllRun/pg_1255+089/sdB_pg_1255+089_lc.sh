#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_pg_1255+089/
python sdB_pg_1255+089_lc.py
date