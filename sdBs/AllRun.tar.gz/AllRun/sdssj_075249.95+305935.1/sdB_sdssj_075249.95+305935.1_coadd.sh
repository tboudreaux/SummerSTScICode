#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj_075249.95+305935.1/
python sdB_sdssj_075249.95+305935.1_coadd.py
date