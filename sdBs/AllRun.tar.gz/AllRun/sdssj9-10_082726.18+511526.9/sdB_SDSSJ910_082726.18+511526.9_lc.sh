#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ910_082726.18+511526.9/
python sdB_SDSSJ910_082726.18+511526.9_lc.py
date