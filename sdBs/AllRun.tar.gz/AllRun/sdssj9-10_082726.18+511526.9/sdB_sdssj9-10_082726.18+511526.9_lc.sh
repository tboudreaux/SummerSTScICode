#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj9-10_082726.18+511526.9/
python sdB_sdssj9-10_082726.18+511526.9_lc.py
date