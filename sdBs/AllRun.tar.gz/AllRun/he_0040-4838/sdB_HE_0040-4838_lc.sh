#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_HE_0040-4838/
python sdB_HE_0040-4838_lc.py
date