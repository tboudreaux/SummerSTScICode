#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_he_0040-4838/
python sdB_he_0040-4838_coadd.py
date