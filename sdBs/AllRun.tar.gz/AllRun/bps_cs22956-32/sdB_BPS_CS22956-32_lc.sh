#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_BPS_CS22956-32/
python sdB_BPS_CS22956-32_lc.py
date