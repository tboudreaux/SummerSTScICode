#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_GALEX_J13317-1948/
python sdB_GALEX_J13317-1948_lc.py
date