#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ910_153834.07+030812.9/
python sdB_SDSSJ910_153834.07+030812.9_lc.py
date