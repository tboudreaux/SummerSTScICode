#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_PG_0917+037/
python sdB_PG_0917+037_coadd.py
date