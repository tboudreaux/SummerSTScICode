#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_pg_0917+037/
python sdB_pg_0917+037_lc.py
date