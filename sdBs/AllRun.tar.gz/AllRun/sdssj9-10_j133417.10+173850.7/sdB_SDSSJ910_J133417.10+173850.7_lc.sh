#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ910_J133417.10+173850.7/
python sdB_SDSSJ910_J133417.10+173850.7_lc.py
date