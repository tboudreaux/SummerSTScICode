#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_UVO_0711+22/
python sdB_UVO_0711+22_lc.py
date