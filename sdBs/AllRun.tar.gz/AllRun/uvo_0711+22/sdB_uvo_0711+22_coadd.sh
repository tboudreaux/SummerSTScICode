#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_uvo_0711+22/
python sdB_uvo_0711+22_coadd.py
date