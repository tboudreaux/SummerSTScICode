#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_GALEX_J18325-4744/
python sdB_GALEX_J18325-4744_coadd.py
date