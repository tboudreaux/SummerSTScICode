#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_galex_j18325-4744/
python sdB_galex_j18325-4744_lc.py
date