#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_galex_j10027-0605/
python sdB_galex_j10027-0605_coadd.py
date