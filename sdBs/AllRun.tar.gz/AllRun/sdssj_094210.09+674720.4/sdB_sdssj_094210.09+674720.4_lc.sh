#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj_094210.09+674720.4/
python sdB_sdssj_094210.09+674720.4_lc.py
date