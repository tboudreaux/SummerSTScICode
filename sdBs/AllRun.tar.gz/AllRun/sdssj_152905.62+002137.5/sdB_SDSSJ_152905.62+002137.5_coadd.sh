#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ_152905.62+002137.5/
python sdB_SDSSJ_152905.62+002137.5_coadd.py
date