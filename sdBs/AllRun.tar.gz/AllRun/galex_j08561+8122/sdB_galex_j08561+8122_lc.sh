#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_galex_j08561+8122/
python sdB_galex_j08561+8122_lc.py
date