#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_HS_0040+4417/
python sdB_HS_0040+4417_lc.py
date