#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj_085809.09+252134.6/
python sdB_sdssj_085809.09+252134.6_lc.py
date