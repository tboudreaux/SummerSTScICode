#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_mct_0004-2737/
python sdB_mct_0004-2737_lc.py
date