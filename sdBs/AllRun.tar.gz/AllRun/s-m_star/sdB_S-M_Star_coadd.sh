#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_S-M_Star/
python sdB_S-M_Star_coadd.py
date