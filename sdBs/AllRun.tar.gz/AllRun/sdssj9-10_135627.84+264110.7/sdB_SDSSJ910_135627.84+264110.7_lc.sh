#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ910_135627.84+264110.7/
python sdB_SDSSJ910_135627.84+264110.7_lc.py
date