#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj_161014.87+045046.6/
python sdB_sdssj_161014.87+045046.6_coadd.py
date