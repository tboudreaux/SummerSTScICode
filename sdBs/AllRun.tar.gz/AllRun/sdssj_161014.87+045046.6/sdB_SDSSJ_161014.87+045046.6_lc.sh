#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ_161014.87+045046.6/
python sdB_SDSSJ_161014.87+045046.6_lc.py
date