#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_EC_14411-0750/
python sdB_EC_14411-0750_coadd.py
date