#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj9-10_135150.62+035718.0/
python sdB_sdssj9-10_135150.62+035718.0_coadd.py
date