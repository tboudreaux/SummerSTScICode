#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ910_135150.62+035718.0/
python sdB_SDSSJ910_135150.62+035718.0_coadd.py
date