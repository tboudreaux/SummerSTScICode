#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj9-10_j161624.36+265314.7/
python sdB_sdssj9-10_j161624.36+265314.7_lc.py
date