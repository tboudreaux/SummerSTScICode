#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_GALEX_J11593-0401/
python sdB_GALEX_J11593-0401_coadd.py
date