#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_pg_1416+110/
python sdB_pg_1416+110_lc.py
date