#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ910_083612.02+191755.8/
python sdB_SDSSJ910_083612.02+191755.8_lc.py
date