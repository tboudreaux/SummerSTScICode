#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj_023652.54+254231.0/
python sdB_sdssj_023652.54+254231.0_coadd.py
date