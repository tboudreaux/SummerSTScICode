#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_pg_1555+504/
python sdB_pg_1555+504_coadd.py
date