#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_PG_1612+736/
python sdB_PG_1612+736_coadd.py
date