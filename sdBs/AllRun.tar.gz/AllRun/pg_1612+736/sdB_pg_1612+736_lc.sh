#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_pg_1612+736/
python sdB_pg_1612+736_lc.py
date