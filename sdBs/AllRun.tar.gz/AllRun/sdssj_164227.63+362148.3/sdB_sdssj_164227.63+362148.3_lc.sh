#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj_164227.63+362148.3/
python sdB_sdssj_164227.63+362148.3_lc.py
date