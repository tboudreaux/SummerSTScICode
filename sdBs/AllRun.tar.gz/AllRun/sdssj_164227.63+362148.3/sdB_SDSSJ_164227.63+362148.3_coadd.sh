#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ_164227.63+362148.3/
python sdB_SDSSJ_164227.63+362148.3_coadd.py
date