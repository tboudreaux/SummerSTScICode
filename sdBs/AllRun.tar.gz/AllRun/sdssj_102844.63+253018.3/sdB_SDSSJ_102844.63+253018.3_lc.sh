#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ_102844.63+253018.3/
python sdB_SDSSJ_102844.63+253018.3_lc.py
date