#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_PG_1119+619/
python sdB_PG_1119+619_coadd.py
date