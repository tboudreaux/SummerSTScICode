#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_sdssj_224635.23+304812.9/
python sdB_sdssj_224635.23+304812.9_coadd.py
date