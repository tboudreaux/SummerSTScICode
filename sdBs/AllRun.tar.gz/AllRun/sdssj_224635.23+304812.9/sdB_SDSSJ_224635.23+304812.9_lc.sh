#!/bin/tcsh
date
mkdir -p /data2/fleming/GPHOTON_OUTPUT/LIGHTCURVES/sdBs/sdB_SDSSJ_224635.23+304812.9/
python sdB_SDSSJ_224635.23+304812.9_lc.py
date